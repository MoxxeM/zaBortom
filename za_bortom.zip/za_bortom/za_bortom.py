from app import app

"""
from flask import Flask, render_template, request, redirect
from hashlib import md5
from datetime import datetime

app = Flask(__name__)
website_constants = {'project_name': '"За Бортом" Онлайн', 'url': '', 'year_of_creation': '2020', 'current_year':
                     str(datetime.now().year)}


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        player_name, room_id = request.form.get('player_name'), request.form.get('room_id')
    return render_template('index.html', context=website_constants)


@app.route('/create', methods=['GET', 'POST'])
def create_room():
    pass


@app.route('/game/<game_hash>', methods=['GET', 'POST'])
def game_room(game_hash):
    pass


if __name__ == '__main__':
    app.run('127.0.0.1', port=5000, debug=True)
"""
